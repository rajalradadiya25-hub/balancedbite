<?php

error_reporting(0);
require('db/dbconnect.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ Page</title>
    <?php require("component/Designlinks.php"); ?>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .faq-section {
            padding: 60px 0;
        }

        .faq-title {
            text-align: center;
            margin-bottom: 40px;
        }

        .faq-title h2 {
            font-size: 2.5rem;
            font-weight: 700;
        }

        .search-bar .input-group {
            max-width: 600px;
            margin: 0 auto;
            position: relative;
        }

        .faq .card {
            margin-bottom: 20px;
        }

        .faq .card-header {
            background-color: #f8f9fa;
            border: 1px solid #ddd;
        }

        .faq .card-body {
            border-top: 1px solid #ddd;
        }

        .contact-section {
            text-align: center;
            margin-top: 50px;
        }
    </style>
</head>

<body>
    <?php require("component/nav.php"); ?>
    <div class="container faq-section">
        <div class="faq-title">
            <h2 style="color: rgb(0,128,0);">Frequently Asked Questions</h2>
        </div>
        <div class="search-bar">
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="searchInput" placeholder="Search FAQs">
                <button class="btn btn-success" type="button" id="searchButton">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>


        <div id="faqCategories">
            <!-- General Nutrition Category -->
            <h3 class="mt-5">General Nutrition</h3>
            <div class="accordion" id="generalFAQ">
                <div class="card mt-2 border">
                    <div class="card-header" id="genHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#genCollapseOne" aria-expanded="true" aria-controls="genCollapseOne">
                                What are macronutrients and why are they important?
                            </button>
                        </h5>
                    </div>
                    <div id="genCollapseOne" class="collapse show" aria-labelledby="genHeadingOne" data-bs-parent="#generalFAQ">
                        <div class="card-body">
                            Macronutrients are nutrients that the body needs in large amounts to function properly. They include carbohydrates, proteins, and fats. They provide energy, support bodily functions, and help in growth and repair.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="genHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#genCollapseOne1" aria-expanded="true" aria-controls="genCollapseOne1">
                                How much water should I drink daily?
                            </button>
                        </h5>
                    </div>
                    <div id="genCollapseOne1" class="collapse" aria-labelledby="genHeadingOne" data-bs-parent="#generalFAQ">
                        <div class="card-body">
                            It is generally recommended to drink about 8 glasses (2 liters) of water daily. However, the amount can vary based on individual needs, activity level, and climate.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="genHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#genCollapseOne2" aria-expanded="true" aria-controls="genCollapseOne2">
                                What is a balanced diet?
                            </button>
                        </h5>
                    </div>
                    <div id="genCollapseOne2" class="collapse" aria-labelledby="genHeadingOne" data-bs-parent="#generalFAQ">
                        <div class="card-body">
                            A balanced diet includes a variety of foods in the right proportions: carbohydrates, proteins, fats, vitamins, minerals, and water. It should provide sufficient calories to maintain a healthy weight.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="genHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#genCollapseOne3" aria-expanded="true" aria-controls="genCollapseOne3">
                                Why are vitamins and minerals important?
                            </button>
                        </h5>
                    </div>
                    <div id="genCollapseOne3" class="collapse" aria-labelledby="genHeadingOne" data-bs-parent="#generalFAQ">
                        <div class="card-body">
                            Vitamins and minerals are essential for various bodily functions, including immune support, energy production, and bone health. They help the body function optimally.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="genHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#genCollapseOne4" aria-expanded="true" aria-controls="genCollapseOne4">
                                How can I ensure I'm getting enough fiber?
                            </button>
                        </h5>
                    </div>
                    <div id="genCollapseOne4" class="collapse" aria-labelledby="genHeadingOne" data-bs-parent="#generalFAQ">
                        <div class="card-body">
                            To ensure adequate fiber intake, include plenty of fruits, vegetables, whole grains, and legumes in your diet. Aim for at least 25-30 grams of fiber per day.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="genHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#genCollapseOne5" aria-expanded="true" aria-controls="genCollapseOne5">
                                What are the benefits of eating whole foods?
                            </button>
                        </h5>
                    </div>
                    <div id="genCollapseOne5" class="collapse" aria-labelledby="genHeadingOne" data-bs-parent="#generalFAQ">
                        <div class="card-body">
                            Whole foods are minimally processed and rich in nutrients. They provide more fiber, vitamins, and minerals compared to processed foods, and support overall health.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="genHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#genCollapseOne6" aria-expanded="true" aria-controls="genCollapseOne6">
                                What is the role of carbohydrates in the diet?
                            </button>
                        </h5>
                    </div>
                    <div id="genCollapseOne6" class="collapse" aria-labelledby="genHeadingOne" data-bs-parent="#generalFAQ">
                        <div class="card-body">
                            Carbohydrates are the body's main source of energy. They fuel the brain, kidneys, heart muscles, and central nervous system.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="genHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#genCollapseOne7" aria-expanded="true" aria-controls="genCollapseOne7">
                                How much protein do I need daily?
                            </button>
                        </h5>
                    </div>
                    <div id="genCollapseOne7" class="collapse" aria-labelledby="genHeadingOne" data-bs-parent="#generalFAQ">
                        <div class="card-body">
                            The recommended dietary allowance (RDA) for protein is 0.8 grams per kilogram of body weight. This can vary based on age, activity level, and health goals.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="genHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#genCollapseOne8" aria-expanded="true" aria-controls="genCollapseOne8">
                                Why are healthy fats important?
                            </button>
                        </h5>
                    </div>
                    <div id="genCollapseOne8" class="collapse" aria-labelledby="genHeadingOne" data-bs-parent="#generalFAQ">
                        <div class="card-body">
                            Healthy fats, such as those found in avocados, nuts, and olive oil, support cell growth, protect organs, and help the body absorb essential vitamins.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="genHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#genCollapseOne9" aria-expanded="true" aria-controls="genCollapseOne9">
                                What are antioxidants and their benefits?
                            </button>
                        </h5>
                    </div>
                    <div id="genCollapseOne9" class="collapse" aria-labelledby="genHeadingOne" data-bs-parent="#generalFAQ">
                        <div class="card-body">
                            Antioxidants are compounds that protect cells from damage caused by free radicals. They can help reduce the risk of chronic diseases and support overall health.
                        </div>
                    </div>
                </div>
            </div>

            <!-- Diet Plans Category -->
            <h3 class="mt-5">Diet Plans</h3>
            <div class="accordion" id="dietFAQ">
                <div class="card mt-2 border">
                    <div class="card-header" id="dietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#dietCollapseOne" aria-expanded="true" aria-controls="dietCollapseOne">
                                Which diet plan is best for weight loss?
                            </button>
                        </h5>
                    </div>
                    <div id="dietCollapseOne" class="collapse" aria-labelledby="dietHeadingOne" data-bs-parent="#dietFAQ">
                        <div class="card-body">
                            The best diet plan for weight loss varies by individual. Common effective plans include the Mediterranean diet, low-carb diets, and intermittent fasting. It's important to choose one that fits your lifestyle and preferences.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="dietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#dietCollapseOne1" aria-expanded="true" aria-controls="dietCollapseOne1">
                                What is the Keto diet?
                            </button>
                        </h5>
                    </div>
                    <div id="dietCollapseOne1" class="collapse" aria-labelledby="dietHeadingOne" data-bs-parent="#dietFAQ">
                        <div class="card-body">
                            The Keto diet is a low-carb, high-fat diet that aims to induce a state of ketosis, where the body burns fat for fuel instead of carbohydrates. It can help with weight loss and improve certain health markers.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="dietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#dietCollapseOne2" aria-expanded="true" aria-controls="dietCollapseOne2">
                                How do I choose the right diet plan for me?
                            </button>
                        </h5>
                    </div>
                    <div id="dietCollapseOne2" class="collapse" aria-labelledby="dietHeadingOne" data-bs-parent="#dietFAQ">
                        <div class="card-body">
                            Consider your health goals, dietary preferences, lifestyle, and any medical conditions. It may be helpful to consult with a dietitian or nutritionist.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="dietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#dietCollapseOne3" aria-expanded="true" aria-controls="dietCollapseOne3">
                                What are the benefits of intermittent fasting?
                            </button>
                        </h5>
                    </div>
                    <div id="dietCollapseOne3" class="collapse" aria-labelledby="dietHeadingOne" data-bs-parent="#dietFAQ">
                        <div class="card-body">
                            Intermittent fasting can help with weight loss, improve metabolism, reduce inflammation, and enhance brain function. It involves cycling between periods of eating and fasting.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="dietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#dietCollapseOne4" aria-expanded="true" aria-controls="dietCollapseOne4">
                                Can I follow a diet plan while being vegetarian?
                            </button>
                        </h5>
                    </div>
                    <div id="dietCollapseOne4" class="collapse" aria-labelledby="dietHeadingOne" data-bs-parent="#dietFAQ">
                        <div class="card-body">
                            Yes, many diet plans can be adapted to a vegetarian lifestyle. Focus on plant-based protein sources, whole grains, and a variety of fruits and vegetables.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="dietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#dietCollapseOne5" aria-expanded="true" aria-controls="dietCollapseOne5">
                                What is the Mediterranean diet?
                            </button>
                        </h5>
                    </div>
                    <div id="dietCollapseOne5" class="collapse" aria-labelledby="dietHeadingOne" data-bs-parent="#dietFAQ">
                        <div class="card-body">
                            The Mediterranean diet emphasizes fruits, vegetables, whole grains, legumes, nuts, and olive oil. It includes moderate amounts of fish, poultry, and dairy, and limits red meat and processed foods.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="dietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#dietCollapseOne6" aria-expanded="true" aria-controls="dietCollapseOne6">
                                What are the benefits of a low-carb diet?
                            </button>
                        </h5>
                    </div>
                    <div id="dietCollapseOne6" class="collapse" aria-labelledby="dietHeadingOne" data-bs-parent="#dietFAQ">
                        <div class="card-body">
                            A low-carb diet can help with weight loss, improve blood sugar control, and reduce the risk of metabolic syndrome and cardiovascular diseases.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="dietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#dietCollapseOne7" aria-expanded="true" aria-controls="dietCollapseOne7">
                                How can I stick to a diet plan long-term?
                            </button>
                        </h5>
                    </div>
                    <div id="dietCollapseOne7" class="collapse" aria-labelledby="dietHeadingOne" data-bs-parent="#dietFAQ">
                        <div class="card-body">
                            Choose a plan that is sustainable and enjoyable. Set realistic goals, track your progress, and seek support from friends, family, or a support group.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="dietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#dietCollapseOne8" aria-expanded="true" aria-controls="dietCollapseOne8">
                                What is a plant-based diet?
                            </button>
                        </h5>
                    </div>
                    <div id="dietCollapseOne8" class="collapse" aria-labelledby="dietHeadingOne" data-bs-parent="#dietFAQ">
                        <div class="card-body">
                            A plant-based diet focuses on foods derived from plants, including vegetables, fruits, grains, nuts, and seeds. It can include small amounts of animal products but emphasizes plant foods.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="dietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#dietCollapseOne9" aria-expanded="true" aria-controls="dietCollapseOne9">
                                How do I prevent nutrient deficiencies on a restrictive diet?
                            </button>
                        </h5>
                    </div>
                    <div id="dietCollapseOne9" class="collapse" aria-labelledby="dietHeadingOne" data-bs-parent="#dietFAQ">
                        <div class="card-body">
                            Ensure a varied diet that includes all food groups, consider fortified foods, and possibly take supplements as recommended by a healthcare provider.
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recipes and Meal Planning Category -->
            <h3 class="mt-5">Recipes and Meal Planning</h3>
            <div class="accordion" id="recipeFAQ">
                <div class="card mt-2 border">
                    <div class="card-header" id="recipeHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#recipeCollapseOne" aria-expanded="true" aria-controls="recipeCollapseOne">
                                Can you provide some healthy breakfast recipes?
                            </button>
                        </h5>
                    </div>
                    <div id="recipeCollapseOne" class="collapse" aria-labelledby="recipeHeadingOne" data-bs-parent="#recipeFAQ">
                        <div class="card-body">
                            Sure! Here are a few ideas: Greek yogurt with berries and honey, oatmeal topped with nuts and fruits, and avocado toast with poached eggs.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="recipeHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#recipeCollapseOne1" aria-expanded="true" aria-controls="recipeCollapseOne1">
                                What are some quick and easy lunch ideas?
                            </button>
                        </h5>
                    </div>
                    <div id="recipeCollapseOne1" class="collapse" aria-labelledby="recipeHeadingOne" data-bs-parent="#recipeFAQ">
                        <div class="card-body">
                            Try a quinoa salad with mixed vegetables, a whole-grain wrap with lean turkey and veggies, or a chickpea and spinach stir-fry.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="recipeHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#recipeCollapseOne2" aria-expanded="true" aria-controls="recipeCollapseOne2">
                                How can I meal prep for the week?
                            </button>
                        </h5>
                    </div>
                    <div id="recipeCollapseOne2" class="collapse" aria-labelledby="recipeHeadingOne" data-bs-parent="#recipeFAQ">
                        <div class="card-body">
                            Plan your meals, create a shopping list, and set aside a few hours on a weekend to cook in bulk. Store meals in portioned containers for easy access throughout the week.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="recipeHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#recipeCollapseOne3" aria-expanded="true" aria-controls="recipeCollapseOne3">
                                What are some healthy snack options?
                            </button>
                        </h5>
                    </div>
                    <div id="recipeCollapseOne3" class="collapse" aria-labelledby="recipeHeadingOne" data-bs-parent="#recipeFAQ">
                        <div class="card-body">
                            Healthy snacks include hummus with veggies, mixed nuts, apple slices with almond butter, and Greek yogurt with honey.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="recipeHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#recipeCollapseOne4" aria-expanded="true" aria-controls="recipeCollapseOne4">
                                Can you suggest some dinner recipes for a balanced diet?
                            </button>
                        </h5>
                    </div>
                    <div id="recipeCollapseOne4" class="collapse" aria-labelledby="recipeHeadingOne" data-bs-parent="#recipeFAQ">
                        <div class="card-body">
                            Baked salmon with roasted vegetables, chicken stir-fry with brown rice, and lentil soup with a side salad are all great options.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="recipeHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#recipeCollapseOne5" aria-expanded="true" aria-controls="recipeCollapseOne5">
                                How can I make my meals more nutritious?
                            </button>
                        </h5>
                    </div>
                    <div id="recipeCollapseOne5" class="collapse" aria-labelledby="recipeHeadingOne" data-bs-parent="#recipeFAQ">
                        <div class="card-body">
                            Add more fruits and vegetables, use whole grains instead of refined grains, include lean proteins, and opt for healthy fats like olive oil and avocados.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="recipeHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#recipeCollapseOne6" aria-expanded="true" aria-controls="recipeCollapseOne6">
                                What are some low-carb meal ideas?
                            </button>
                        </h5>
                    </div>
                    <div id="recipeCollapseOne6" class="collapse" aria-labelledby="recipeHeadingOne" data-bs-parent="#recipeFAQ">
                        <div class="card-body">
                            Grilled chicken with sautéed greens, zucchini noodles with marinara sauce, and a spinach and cheese omelet are all low-carb and delicious.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="recipeHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#recipeCollapseOne7" aria-expanded="true" aria-controls="recipeCollapseOne7">
                                How can I create a balanced meal plan?
                            </button>
                        </h5>
                    </div>
                    <div id="recipeCollapseOne7" class="collapse" aria-labelledby="recipeHeadingOne" data-bs-parent="#recipeFAQ">
                        <div class="card-body">
                            Include a variety of foods from all food groups, ensure appropriate portion sizes, and plan for three main meals and two snacks each day.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="recipeHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#recipeCollapseOne8" aria-expanded="true" aria-controls="recipeCollapseOne8">
                                Can you provide some vegetarian meal ideas?
                            </button>
                        </h5>
                    </div>
                    <div id="recipeCollapseOne8" class="collapse" aria-labelledby="recipeHeadingOne" data-bs-parent="#recipeFAQ">
                        <div class="card-body">
                            Try a black bean and sweet potato burrito, tofu stir-fry with vegetables, or a chickpea and spinach curry.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="recipeHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#recipeCollapseOne9" aria-expanded="true" aria-controls="recipeCollapseOne9">
                                What are the benefits of meal planning?

                            </button>
                        </h5>
                    </div>
                    <div id="recipeCollapseOne9" class="collapse" aria-labelledby="recipeHeadingOne" data-bs-parent="#recipeFAQ">
                        <div class="card-body">
                            Meal planning can save time, reduce stress, help with portion control, ensure a balanced diet, and save money by reducing food waste.
                        </div>
                    </div>
                </div>
            </div>

            <!-- Special Dietary Needs Category -->
            <h3 class="mt-5">Special Dietary Needs</h3>
            <div class="accordion" id="specdietFAQ">
                <div class="card mt-2 border">
                    <div class="card-header" id="specdietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#specdietCollapseOne" aria-expanded="true" aria-controls="specdietCollapseOne">
                                What are some gluten-free diet tips?
                            </button>
                        </h5>
                    </div>
                    <div id="specdietCollapseOne" class="collapse" aria-labelledby="specdietHeadingOne" data-bs-parent="#specdietFAQ">
                        <div class="card-body">
                            Read labels carefully, opt for naturally gluten-free foods like fruits and vegetables, and experiment with gluten-free grains like quinoa, rice, and millet.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="specdietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#specdietCollapseOne1" aria-expanded="true" aria-controls="specdietCollapseOne1">
                                How can I follow a vegan diet and get enough protein?
                            </button>
                        </h5>
                    </div>
                    <div id="specdietCollapseOne1" class="collapse" aria-labelledby="specdietHeadingOne" data-bs-parent="#specdietFAQ">
                        <div class="card-body">
                            Include a variety of plant-based protein sources such as beans, lentils, tofu, tempeh, and quinoa. Nuts and seeds are also excellent protein-rich options.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="specdietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#specdietCollapseOne2" aria-expanded="true" aria-controls="specdietCollapseOne2">
                                What should I eat if I have a dairy intolerance?
                            </button>
                        </h5>
                    </div>
                    <div id="specdietCollapseOne2" class="collapse" aria-labelledby="specdietHeadingOne" data-bs-parent="#specdietFAQ">
                        <div class="card-body">
                            Choose lactose-free dairy products or dairy alternatives like almond, soy, or oat milk. Include calcium-rich foods such as leafy greens, almonds, and fortified cereals.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="specdietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#specdietCollapseOne3" aria-expanded="true" aria-controls="specdietCollapseOne3">
                                How can I manage a low-sodium diet?
                            </button>
                        </h5>
                    </div>
                    <div id="specdietCollapseOne3" class="collapse" aria-labelledby="specdietHeadingOne" data-bs-parent="#specdietFAQ">
                        <div class="card-body">
                            Cook meals at home, use herbs and spices for flavor instead of salt, read labels for sodium content, and limit processed and packaged foods.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="specdietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#specdietCollapseOne4" aria-expanded="true" aria-controls="specdietCollapseOne4">
                                What are the benefits of a low-carb diet for diabetics?
                            </button>
                        </h5>
                    </div>
                    <div id="specdietCollapseOne4" class="collapse" aria-labelledby="specdietHeadingOne" data-bs-parent="#specdietFAQ">
                        <div class="card-body">
                            A low-carb diet can help manage blood sugar levels, reduce insulin resistance, and promote weight loss, which is beneficial for diabetics.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="specdietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#specdietCollapseOne5" aria-expanded="true" aria-controls="specdietCollapseOne5">
                                How can I follow an anti-inflammatory diet?
                            </button>
                        </h5>
                    </div>
                    <div id="specdietCollapseOne5" class="collapse" aria-labelledby="specdietHeadingOne" data-bs-parent="#specdietFAQ">
                        <div class="card-body">
                            Include plenty of fruits, vegetables, whole grains, healthy fats, and lean proteins. Limit processed foods, sugars, and unhealthy fats.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="specdietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#specdietCollapseOne6" aria-expanded="true" aria-controls="specdietCollapseOne6">
                                What are some dairy-free calcium sources?
                            </button>
                        </h5>
                    </div>
                    <div id="specdietCollapseOne6" class="collapse" aria-labelledby="specdietHeadingOne" data-bs-parent="#specdietFAQ">
                        <div class="card-body">
                            Dairy-free calcium sources include leafy greens, almonds, fortified plant-based milks, tofu, and canned fish with bones like sardines and salmon.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="specdietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#specdietCollapseOne7" aria-expanded="true" aria-controls="specdietCollapseOne7">
                                How can I manage a diet for irritable bowel syndrome (IBS)?
                            </button>
                        </h5>
                    </div>
                    <div id="specdietCollapseOne7" class="collapse" aria-labelledby="specdietHeadingOne" data-bs-parent="#specdietFAQ">
                        <div class="card-body">
                            Follow a low-FODMAP diet, which eliminates certain carbohydrates that can cause IBS symptoms. Consult with a dietitian for personalized advice.

                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="specdietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#specdietCollapseOne8" aria-expanded="true" aria-controls="specdietCollapseOne8">
                                What foods should I avoid with a nut allergy?
                            </button>
                        </h5>
                    </div>
                    <div id="specdietCollapseOne8" class="collapse" aria-labelledby="specdietHeadingOne" data-bs-parent="#specdietFAQ">
                        <div class="card-body">
                            Avoid all nuts and nut-containing products. Read labels carefully and be cautious with foods that may be cross-contaminated with nuts.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="specdietHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#specdietCollapseOne9" aria-expanded="true" aria-controls="specdietCollapseOne9">
                                How can I ensure a balanced diet with food allergies?

                            </button>
                        </h5>
                    </div>
                    <div id="specdietCollapseOne9" class="collapse" aria-labelledby="specdietHeadingOne" data-bs-parent="#specdietFAQ">
                        <div class="card-body">
                            Focus on safe, nutrient-dense foods that you can eat, plan meals carefully, and consider working with a dietitian to ensure you're meeting your nutritional needs.
                        </div>
                    </div>
                </div>
            </div>

            <!-- Supplements and Vitamins Category -->
            <h3 class="mt-5">Supplements and Vitamins</h3>
            <div class="accordion" id="supplementFAQ">
                <div class="card mt-2 border">
                    <div class="card-header" id="supplementHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supplementCollapseOne" aria-expanded="true" aria-controls="supplementCollapseOne">
                                Do I need supplements if I eat a balanced diet?
                            </button>
                        </h5>
                    </div>
                    <div id="supplementCollapseOne" class="collapse" aria-labelledby="supplementHeadingOne" data-bs-parent="#supplementFAQ">
                        <div class="card-body">
                            Generally, if you eat a varied and balanced diet, you may not need supplements. However, certain conditions or dietary restrictions may require supplementation. Consult with a healthcare provider.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supplementHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supplementCollapseOne1" aria-expanded="true" aria-controls="supplementCollapseOne1">
                                What are the best vitamins for overall health?
                            </button>
                        </h5>
                    </div>
                    <div id="supplementCollapseOne1" class="collapse" aria-labelledby="supplementHeadingOne" data-bs-parent="#supplementFAQ">
                        <div class="card-body">
                            Key vitamins for overall health include Vitamin D, Vitamin C, Vitamin A, and B vitamins. It's best to obtain these through a balanced diet.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supplementHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supplementCollapseOne2" aria-expanded="true" aria-controls="supplementCollapseOne2">
                                How can I safely incorporate supplements into my diet?
                            </button>
                        </h5>
                    </div>
                    <div id="supplementCollapseOne2" class="collapse" aria-labelledby="supplementHeadingOne" data-bs-parent="#supplementFAQ">
                        <div class="card-body">
                            Always consult with a healthcare provider before starting any new supplements. Follow the recommended dosage and choose high-quality products from reputable brands.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supplementHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supplementCollapseOne3" aria-expanded="true" aria-controls="supplementCollapseOne3">
                                What are the benefits of omega-3 fatty acids?
                            </button>
                        </h5>
                    </div>
                    <div id="supplementCollapseOne3" class="collapse" aria-labelledby="supplementHeadingOne" data-bs-parent="#supplementFAQ">
                        <div class="card-body">
                            Omega-3 fatty acids support heart health, brain function, and reduce inflammation. They are found in fatty fish, flaxseeds, and walnuts.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supplementHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supplementCollapseOne4" aria-expanded="true" aria-controls="supplementCollapseOne4">
                                Should I take a multivitamin?
                            </button>
                        </h5>
                    </div>
                    <div id="supplementCollapseOne4" class="collapse" aria-labelledby="supplementHeadingOne" data-bs-parent="#supplementFAQ">
                        <div class="card-body">
                            A multivitamin can help fill nutritional gaps in your diet. Consult with a healthcare provider to determine if a multivitamin is right for you.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supplementHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supplementCollapseOne5" aria-expanded="true" aria-controls="supplementCollapseOne5">
                                What are probiotics and their benefits?
                            </button>
                        </h5>
                    </div>
                    <div id="supplementCollapseOne5" class="collapse" aria-labelledby="supplementHeadingOne" data-bs-parent="#supplementFAQ">
                        <div class="card-body">
                            Probiotics are beneficial bacteria that support gut health. They can improve digestion, boost immunity, and may reduce symptoms of certain gastrointestinal conditions.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supplementHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supplementCollapseOne6" aria-expanded="true" aria-controls="supplementCollapseOne6">
                                How do I know if I need a specific supplement?
                            </button>
                        </h5>
                    </div>
                    <div id="supplementCollapseOne6" class="collapse" aria-labelledby="supplementHeadingOne" data-bs-parent="#supplementFAQ">
                        <div class="card-body">
                            A healthcare provider can assess your dietary intake, health status, and specific needs to determine if you need a supplement.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supplementHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supplementCollapseOne7" aria-expanded="true" aria-controls="supplementCollapseOne7">
                                Can I take too many supplements?
                            </button>
                        </h5>
                    </div>
                    <div id="supplementCollapseOne7" class="collapse" aria-labelledby="supplementHeadingOne" data-bs-parent="#supplementFAQ">
                        <div class="card-body">
                            Yes, excessive intake of certain supplements can be harmful. Always follow recommended dosages and consult with a healthcare provider.

                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supplementHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supplementCollapseOne8" aria-expanded="true" aria-controls="supplementCollapseOne8">
                                What are the benefits of Vitamin D?
                            </button>
                        </h5>
                    </div>
                    <div id="supplementCollapseOne8" class="collapse" aria-labelledby="supplementHeadingOne" data-bs-parent="#supplementFAQ">
                        <div class="card-body">
                            Vitamin D supports bone health, immune function, and may improve mood. It is synthesized through sun exposure and found in certain foods.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supplementHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supplementCollapseOne9" aria-expanded="true" aria-controls="supplementCollapseOne9">
                                How can I ensure I'm getting enough iron?
                            </button>
                        </h5>
                    </div>
                    <div id="supplementCollapseOne9" class="collapse" aria-labelledby="supplementHeadingOne" data-bs-parent="#supplementFAQ">
                        <div class="card-body">
                            Include iron-rich foods such as red meat, poultry, beans, lentils, and fortified cereals in your diet. Vitamin C can enhance iron absorption.
                        </div>
                    </div>
                </div>
            </div>

            <!-- Health and Wellness Category -->
            <h3 class="mt-5">Health and Wellness</h3>
            <div class="accordion" id="healthFAQ">
                <div class="card mt-2 border">
                    <div class="card-header" id="healthHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#healthCollapseOne" aria-expanded="true" aria-controls="healthCollapseOne">
                                How does diet affect mental health?
                            </button>
                        </h5>
                    </div>
                    <div id="healthCollapseOne" class="collapse" aria-labelledby="healthHeadingOne" data-bs-parent="#healthFAQ">
                        <div class="card-body">
                            A balanced diet supports brain function, reduces inflammation, and provides essential nutrients. Nutrient deficiencies can impact mood and cognitive function.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="healthHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#healthCollapseOne1" aria-expanded="true" aria-controls="healthCollapseOne1">
                                What are the benefits of regular exercise in a diet plan?
                            </button>
                        </h5>
                    </div>
                    <div id="healthCollapseOne1" class="collapse" aria-labelledby="healthHeadingOne" data-bs-parent="#healthFAQ">
                        <div class="card-body">
                            Regular exercise enhances weight management, improves cardiovascular health, boosts mood, and increases energy levels. It complements a healthy diet.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="healthHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#healthCollapseOne2" aria-expanded="true" aria-controls="healthCollapseOne2">
                                How can I improve my digestive health through diet?
                            </button>
                        </h5>
                    </div>
                    <div id="healthCollapseOne2" class="collapse" aria-labelledby="healthHeadingOne" data-bs-parent="#healthFAQ">
                        <div class="card-body">
                            Include fiber-rich foods, stay hydrated, eat probiotic-rich foods, and avoid processed foods. Regular meals and a balanced diet support digestion.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="healthHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#healthCollapseOne3" aria-expanded="true" aria-controls="healthCollapseOne3">
                                What are the effects of stress on diet and nutrition?
                            </button>
                        </h5>
                    </div>
                    <div id="healthCollapseOne3" class="collapse" aria-labelledby="healthHeadingOne" data-bs-parent="#healthFAQ">
                        <div class="card-body">
                            Stress can lead to poor dietary choices, overeating, or loss of appetite. Managing stress through relaxation techniques and a balanced diet is important.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="healthHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#healthCollapseOne4" aria-expanded="true" aria-controls="healthCollapseOne4">
                                How does sleep impact nutrition and weight?
                            </button>
                        </h5>
                    </div>
                    <div id="healthCollapseOne4" class="collapse" aria-labelledby="healthHeadingOne" data-bs-parent="#healthFAQ">
                        <div class="card-body">
                            Poor sleep can disrupt hunger hormones, leading to overeating and weight gain. Quality sleep supports metabolism and overall health.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="healthHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#healthCollapseOne5" aria-expanded="true" aria-controls="healthCollapseOne5">
                                Can diet help with anxiety and depression?
                            </button>
                        </h5>
                    </div>
                    <div id="healthCollapseOne5" class="collapse" aria-labelledby="healthHeadingOne" data-bs-parent="#healthFAQ">
                        <div class="card-body">
                            Certain nutrients, such as omega-3 fatty acids, B vitamins, and antioxidants, may support mental health. A balanced diet can improve mood and reduce symptoms.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="healthHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#healthCollapseOne6" aria-expanded="true" aria-controls="healthCollapseOne6">
                                What are some tips for healthy eating on a busy schedule?
                            </button>
                        </h5>
                    </div>
                    <div id="healthCollapseOne6" class="collapse" aria-labelledby="healthHeadingOne" data-bs-parent="#healthFAQ">
                        <div class="card-body">
                            Plan and prep meals in advance, choose quick and nutritious options, keep healthy snacks on hand, and avoid skipping meals.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="healthHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#healthCollapseOne7" aria-expanded="true" aria-controls="healthCollapseOne7">
                                How can hydration affect overall health?
                            </button>
                        </h5>
                    </div>
                    <div id="healthCollapseOne7" class="collapse" aria-labelledby="healthHeadingOne" data-bs-parent="#healthFAQ">
                        <div class="card-body">
                            Hydration supports digestion, nutrient absorption, and skin health. It also helps maintain energy levels and cognitive function.

                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="healthHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#healthCollapseOne8" aria-expanded="true" aria-controls="healthCollapseOne8">
                                What role do antioxidants play in health?
                            </button>
                        </h5>
                    </div>
                    <div id="healthCollapseOne8" class="collapse" aria-labelledby="healthHeadingOne" data-bs-parent="#healthFAQ">
                        <div class="card-body">
                            Antioxidants protect cells from damage caused by free radicals. They may reduce the risk of chronic diseases and support overall health.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="healthHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#healthCollapseOne9" aria-expanded="true" aria-controls="healthCollapseOne9">
                                How can I incorporate mindfulness into eating?
                            </button>
                        </h5>
                    </div>
                    <div id="healthCollapseOne9" class="collapse" aria-labelledby="healthHeadingOne" data-bs-parent="#healthFAQ">
                        <div class="card-body">
                            Practice mindful eating by paying attention to hunger and fullness cues, savoring each bite, and avoiding distractions during meals.
                        </div>
                    </div>
                </div>
            </div>

            <!-- Common Concerns Category -->
            <h3 class="mt-5">Common Concerns</h3>
            <div class="accordion" id="comconcernFAQ">
                <div class="card mt-2 border">
                    <div class="card-header" id="comconcernHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#comconcernCollapseOne" aria-expanded="true" aria-controls="comconcernCollapseOne">
                                How do I overcome cravings while on a diet?
                            </button>
                        </h5>
                    </div>
                    <div id="comconcernCollapseOne" class="collapse" aria-labelledby="comconcernHeadingOne" data-bs-parent="#comconcernFAQ">
                        <div class="card-body">
                            Identify triggers, plan healthy snacks, stay hydrated, get enough sleep, and practice mindful eating. Allow occasional treats in moderation.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="comconcernHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#comconcernCollapseOne1" aria-expanded="true" aria-controls="comconcernCollapseOne1">
                                What should I do if I hit a weight loss plateau?
                            </button>
                        </h5>
                    </div>
                    <div id="comconcernCollapseOne1" class="collapse" aria-labelledby="comconcernHeadingOne" data-bs-parent="#comconcernFAQ">
                        <div class="card-body">
                            Reassess your diet and exercise routine, consider increasing physical activity, track food intake, and consult with a nutritionist or dietitian.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="comconcernHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#comconcernCollapseOne2" aria-expanded="true" aria-controls="comconcernCollapseOne2">
                                How can I maintain my weight after reaching my goal?
                            </button>
                        </h5>
                    </div>
                    <div id="comconcernCollapseOne2" class="collapse" aria-labelledby="comconcernHeadingOne" data-bs-parent="#comconcernFAQ">
                        <div class="card-body">
                            Continue healthy eating habits, stay active, monitor your weight, and seek support if needed. Consistency is key to long-term maintenance.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="comconcernHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#comconcernCollapseOne3" aria-expanded="true" aria-controls="comconcernCollapseOne3">
                                What are some strategies to manage emotional eating?
                            </button>
                        </h5>
                    </div>
                    <div id="comconcernCollapseOne3" class="collapse" aria-labelledby="comconcernHeadingOne" data-bs-parent="#comconcernFAQ">
                        <div class="card-body">
                            Recognize emotional triggers, practice stress-relief techniques, plan balanced meals, and seek support from a therapist or support group.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="comconcernHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#comconcernCollapseOne4" aria-expanded="true" aria-controls="comconcernCollapseOne4">
                                How can I stay motivated on a long-term diet plan?
                            </button>
                        </h5>
                    </div>
                    <div id="comconcernCollapseOne4" class="collapse" aria-labelledby="comconcernHeadingOne" data-bs-parent="#comconcernFAQ">
                        <div class="card-body">
                            Set realistic goals, track progress, reward yourself for milestones, find a support system, and focus on the benefits of a healthy lifestyle.

                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="comconcernHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#comconcernCollapseOne5" aria-expanded="true" aria-controls="comconcernCollapseOne5">
                                Is it okay to have cheat meals on a diet?
                            </button>
                        </h5>
                    </div>
                    <div id="comconcernCollapseOne5" class="collapse" aria-labelledby="comconcernHeadingOne" data-bs-parent="#comconcernFAQ">
                        <div class="card-body">
                            Occasional cheat meals can be part of a balanced diet. Plan them mindfully and return to your healthy eating habits afterward.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="comconcernHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#comconcernCollapseOne6" aria-expanded="true" aria-controls="comconcernCollapseOne6">
                                How can I prevent portion distortion?
                            </button>
                        </h5>
                    </div>
                    <div id="comconcernCollapseOne6" class="collapse" aria-labelledby="comconcernHeadingOne" data-bs-parent="#comconcernFAQ">
                        <div class="card-body">
                            Use smaller plates, read serving sizes on labels, measure portions, and be mindful of restaurant portions. Listen to your body's hunger cues.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="comconcernHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#comconcernCollapseOne7" aria-expanded="true" aria-controls="comconcernCollapseOne7">
                                What are some healthy ways to handle food cravings?
                            </button>
                        </h5>
                    </div>
                    <div id="comconcernCollapseOne7" class="collapse" aria-labelledby="comconcernHeadingOne" data-bs-parent="#comconcernFAQ">
                        <div class="card-body">
                            Opt for healthy alternatives, stay hydrated, keep busy, and practice moderation. Identify whether the craving is due to hunger or other factors.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="comconcernHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#comconcernCollapseOne8" aria-expanded="true" aria-controls="comconcernCollapseOne8">
                                How can I deal with social situations while on a diet?
                            </button>
                        </h5>
                    </div>
                    <div id="comconcernCollapseOne8" class="collapse" aria-labelledby="comconcernHeadingOne" data-bs-parent="#comconcernFAQ">
                        <div class="card-body">
                            Plan ahead, make healthy choices, communicate your goals, and allow flexibility. Focus on the social aspect rather than just the food.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="comconcernHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#comconcernCollapseOne9" aria-expanded="true" aria-controls="comconcernCollapseOne9">
                                How can I avoid yo-yo dieting?
                            </button>
                        </h5>
                    </div>
                    <div id="comconcernCollapseOne9" class="collapse" aria-labelledby="comconcernHeadingOne" data-bs-parent="#comconcernFAQ">
                        <div class="card-body">
                            Adopt sustainable eating habits, avoid extreme restrictions, focus on long-term health, and seek professional guidance if needed.
                        </div>
                    </div>
                </div>
            </div>

            <!-- Support and Resources Category -->
            <h3 class="mt-5">Support and Resources</h3>
            <div class="accordion" id="supportFAQ">
                <div class="card mt-2 border">
                    <div class="card-header" id="supportHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supportCollapseOne" aria-expanded="true" aria-controls="supportCollapseOne">
                                Where can I find a nutritionist or dietitian?
                            </button>
                        </h5>
                    </div>
                    <div id="supportCollapseOne" class="collapse" aria-labelledby="supportHeadingOne" data-bs-parent="#supportFAQ">
                        <div class="card-body">
                            You can find a nutritionist or dietitian through referrals from your primary care provider, local health clinics, or professional organizations like the Academy of Nutrition and Dietetics.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supportHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supportCollapseOne1" aria-expanded="true" aria-controls="supportCollapseOne1">
                                Are there any good apps for tracking food intake?
                            </button>
                        </h5>
                    </div>
                    <div id="supportCollapseOne1" class="collapse" aria-labelledby="supportHeadingOne" data-bs-parent="#supportFAQ">
                        <div class="card-body">
                            Yes, some popular apps include MyFitnessPal, Lose It!, Cronometer, and Noom. These apps help track food intake, exercise, and progress.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supportHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supportCollapseOne2" aria-expanded="true" aria-controls="supportCollapseOne2">
                                How can I join a diet support group?
                            </button>
                        </h5>
                    </div>
                    <div id="supportCollapseOne2" class="collapse" aria-labelledby="supportHeadingOne" data-bs-parent="#supportFAQ">
                        <div class="card-body">
                            Look for local support groups through community centers, hospitals, or online forums like Meetup, Weight Watchers, and SparkPeople.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supportHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supportCollapseOne3" aria-expanded="true" aria-controls="supportCollapseOne3">
                                What resources are available for meal planning?
                            </button>
                        </h5>
                    </div>
                    <div id="supportCollapseOne3" class="collapse" aria-labelledby="supportHeadingOne" data-bs-parent="#supportFAQ">
                        <div class="card-body">
                            Resources include meal planning websites, apps, cookbooks, and services like meal kit deliveries (e.g., HelloFresh, Blue Apron). These can help you create balanced and nutritious meal plans.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supportHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supportCollapseOne4" aria-expanded="true" aria-controls="supportCollapseOne4">
                                Can I access diet and nutrition information online?
                            </button>
                        </h5>
                    </div>
                    <div id="supportCollapseOne4" class="collapse" aria-labelledby="supportHeadingOne" data-bs-parent="#supportFAQ">
                        <div class="card-body">
                            Yes, reputable websites like the Academy of Nutrition and Dietetics, USDA, and Mayo Clinic offer reliable diet and nutrition information.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supportHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supportCollapseOne5" aria-expanded="true" aria-controls="supportCollapseOne5">
                                What should I look for in a nutrition blog?
                            </button>
                        </h5>
                    </div>
                    <div id="supportCollapseOne5" class="collapse" aria-labelledby="supportHeadingOne" data-bs-parent="#supportFAQ">
                        <div class="card-body">
                            Look for blogs written by registered dietitians or nutritionists, backed by scientific evidence, and free from extreme or fad diet promotions.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supportHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supportCollapseOne6" aria-expanded="true" aria-controls="supportCollapseOne6">
                                Are there free resources for healthy recipes?
                            </button>
                        </h5>
                    </div>
                    <div id="supportCollapseOne6" class="collapse" aria-labelledby="supportHeadingOne" data-bs-parent="#supportFAQ">
                        <div class="card-body">
                            Yes, websites like Allrecipes, EatingWell, and the Food Network offer free healthy recipes. Many nutrition blogs also provide recipe ideas.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supportHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supportCollapseOne7" aria-expanded="true" aria-controls="supportCollapseOne7">
                                How can I stay updated on the latest nutrition research?
                            </button>
                        </h5>
                    </div>
                    <div id="supportCollapseOne7" class="collapse" aria-labelledby="supportHeadingOne" data-bs-parent="#supportFAQ">
                        <div class="card-body">
                            Follow reputable nutrition journals, professional organizations, and trusted health news websites. Subscribing to newsletters from these sources can also help.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supportHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supportCollapseOne8" aria-expanded="true" aria-controls="supportCollapseOne8">
                                What are some good books on nutrition and diet?
                            </button>
                        </h5>
                    </div>
                    <div id="supportCollapseOne8" class="collapse" aria-labelledby="supportHeadingOne" data-bs-parent="#supportFAQ">
                        <div class="card-body">
                            Some recommended books include "How Not to Die" by Michael Greger, "The Blue Zones Solution" by Dan Buettner, and "In Defense of Food" by Michael Pollan.
                        </div>
                    </div>
                </div>
                <div class="card mt-2 border">
                    <div class="card-header" id="supportHeadingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-bs-toggle="collapse" data-bs-target="#supportCollapseOne9" aria-expanded="true" aria-controls="supportCollapseOne9">
                                How do I evaluate the credibility of diet and nutrition information?
                            </button>
                        </h5>
                    </div>
                    <div id="supportCollapseOne9" class="collapse" aria-labelledby="supportHeadingOne" data-bs-parent="#supportFAQ">
                        <div class="card-body">
                            Check the credentials of the author, look for references to scientific studies, and be wary of extreme claims or quick-fix solutions. Trusted sources are key.
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="contact-section">
            <p>Can't find what you're looking for? <a href="contact-us.php">Contact us</a></p>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $("#searchButton").on("click", function() {
                var value = $("#searchInput").val().toLowerCase();
                $("#faqCategories .card").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                });
            });
        });
    </script>

    <?php require("component/Footer.php"); ?>
</body>

</html>